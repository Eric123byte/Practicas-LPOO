
package holamundoem;

import java.time.LocalDate;

public class HolaMundoEM {

    public static void main(String[] args) {
        System.out.println("Eric Morales Sanchez");
        System.out.println("Matricula: 2090509");
        System.out.println(LocalDate.now());
    }
    
}
